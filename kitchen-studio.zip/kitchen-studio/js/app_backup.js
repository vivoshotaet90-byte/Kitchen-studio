import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/controls/OrbitControls.js';

const $ = id => document.getElementById(id);
const viewport = $('viewport');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#e8e9e3');

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
camera.position.set(6, 5.2, 7);

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
viewport.appendChild(renderer.domElement);

const orbit = new OrbitControls(camera, renderer.domElement);
orbit.enableDamping = true;
orbit.target.set(0, 1, 0);
orbit.maxPolarAngle = Math.PI * 0.49;
orbit.minDistance = 3;
orbit.maxDistance = 18;

scene.add(new THREE.HemisphereLight(0xffffff, 0x898b7e, 2));
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(4, 8, 5);
sun.castShadow = true;
scene.add(sun);

const floorMat = new THREE.MeshStandardMaterial({ color: '#d9d9d0', roughness: 0.9 });
const wallMat = new THREE.MeshStandardMaterial({ color: '#f7f5ee', roughness: 0.95, side: THREE.DoubleSide });
const cabinetMat = new THREE.MeshStandardMaterial({ color: '#d8d0c1', roughness: 0.65 });
const topMat = new THREE.MeshStandardMaterial({ color: '#8b897f', roughness: 0.45 });
const detailMat = new THREE.MeshStandardMaterial({ color: '#77776d', metalness: 0.55, roughness: 0.35 });

let room = { width: 4, length: 4, height: 2.7 };
let units = [];
let selected = null;
let nextId = 1;
let facadeColor = '#d8d0c1';
let dragging = false;
let moved = false;
let lastPointer = null;
let pointerDown = null;

const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), floorMat);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.015;
floor.receiveShadow = true;
scene.add(floor);

const roomGroup = new THREE.Group();
scene.add(roomGroup);
const unitGroup = new THREE.Group();
scene.add(unitGroup);

function clearGroup(group) {
  while (group.children.length) {
    const child = group.children[0];
    group.remove(child);
    child.traverse?.(obj => {
      if (obj.geometry) obj.geometry.dispose();
    });
  }
}

function addBox(parent, size, position, material, name = '') {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.part = name;
  parent.add(mesh);
  return mesh;
}

function drawRoom() {
  clearGroup(roomGroup);
  const { width: w, length: l, height: h } = room;
  addBox(roomGroup, [w, 0.08, l], [0, 0, 0], floorMat, 'floor');

  // Back wall and two side walls
  addBox(roomGroup, [w, h, 0.08], [0, h / 2, -l / 2], wallMat, 'wall');
  addBox(roomGroup, [0.08, h, l], [-w / 2, h / 2, 0], wallMat, 'wall');
  addBox(roomGroup, [0.08, h, l], [w / 2, h / 2, 0], wallMat, 'wall');

  // Subtle floor grid
  const grid = new THREE.GridHelper(Math.max(w, l), Math.round(Math.max(w, l) * 2), 0xb7b8ad, 0xd0d1c8);
  grid.position.y = 0.045;
  roomGroup.add(grid);

  orbit.target.set(0, h * 0.38, 0);
  orbit.update();
}

function dimensions(type) {
  if (type === 'tall') return { w: 0.6, h: Math.min(2.2, room.height - 0.2), d: 0.58, price: 4200, name: 'Высокий шкаф' };
  if (type === 'wall') return { w: 0.6, h: 0.72, d: 0.35, price: 2400, name: 'Навесной шкаф' };
  if (type === 'drawer') return { w: 0.6, h: 0.86, d: 0.58, price: 3600, name: 'Шкаф с ящиками' };
  return { w: 0.6, h: 0.86, d: 0.58, price: 2900, name: 'Нижний шкаф' };
}

function buildUnit(data) {
  const dim = dimensions(data.type);
  const group = new THREE.Group();
  group.userData.unitId = data.id;
  group.userData.type = data.type;

  const facade = new THREE.MeshStandardMaterial({ color: data.color || facadeColor, roughness: 0.58 });
  const carcass = new THREE.MeshStandardMaterial({ color: '#a7a397', roughness: 0.85 });
  const isWall = data.type === 'wall';
  const y = isWall ? Math.min(room.height - dim.h / 2 - 0.2, 1.85) : dim.h / 2 + 0.05;

  addBox(group, [dim.w - 0.035, dim.h - 0.035, dim.d - 0.025], [0, 0, 0], carcass, 'body');
  addBox(group, [dim.w - 0.07, dim.h - 0.08, 0.035], [0, 0, dim.d / 2 + 0.02], facade, 'facade');

  if (data.type === 'drawer') {
    for (let i = 0; i < 3; i++) {
      const yy = -dim.h / 2 + dim.h * (i + 0.5) / 3;
      addBox(group, [dim.w * 0.52, 0.025, 0.025], [0, yy, dim.d / 2 + 0.045], detailMat, 'handle');
    }
  } else {
    addBox(group, [0.16, 0.025, 0.025], [0, 0, dim.d / 2 + 0.045], detailMat, 'handle');
  }

  if (!isWall) {
    addBox(group, [dim.w + 0.025, 0.045, dim.d + 0.035], [0, dim.h / 2 + 0.025, 0], topMat, 'countertop');
    addBox(group, [dim.w - 0.07, 0.04, dim.d - 0.07], [0, -dim.h / 2 + 0.025, 0], carcass, 'plinth');
  }

  group.position.set(data.x, y, data.z);
  group.rotation.y = data.rotation || 0;
  group.traverse(obj => {
    if (obj.isMesh) obj.userData.unitId = data.id;
  });
  group.userData.price = dim.price;
  group.userData.name = dim.name;
  group.userData.dim = dim;
  group.userData.saved = { ...data };
  unitGroup.add(group);
  return group;
}

function addUnit(type) {
  const dim = dimensions(type);
  const wall = room.length / 2 - dim.d / 2 - 0.12;
  const x = -room.width / 2 + dim.w / 2 + 0.12 + units.filter(u => u.userData.type !== 'wall').length * 0.62;
  const data = {
    id: nextId++,
    type,
    x: Math.min(x, room.width / 2 - dim.w / 2 - 0.1),
    z: -wall,
    rotation: 0,
    color: facadeColor
  };
  const unit = buildUnit(data);
  units.push(unit);
  selectUnit(unit);
  updateEstimate();
  status('Добавлен модуль: ' + unit.userData.name);
}

function selectUnit(unit) {
  if (selected) selected.traverse(o => {
    if (o.isMesh && o.material?.emissive) o.material.emissive.set('#000000');
  });
  selected = unit;
  if (selected) {
    selected.traverse(o => {
      if (o.isMesh && o.material?.emissive) o.material.emissive.set('#222218');
    });
    $('selectionInfo').textContent = selected.userData.name + ' · ширина 60 см';
  } else {
    $('selectionInfo').textContent = 'Выберите модуль в 3D, чтобы изменить его.';
  }
}

function updateEstimate() {
  const price = units.reduce((sum, u) => sum + u.userData.price, 0);
  const length = units.filter(u => u.userData.type !== 'wall').reduce((sum, u) => sum + u.userData.dim.w, 0);
  $('totalPrice').textContent = price.toLocaleString('ru-RU') + ' MDL';
  $('moduleCount').textContent = units.length;
  $('runLength').textContent = length.toFixed(1) + ' м';
}

function status(message) {
  $('status').textContent = message;
}

function applyRoom() {
  const w = Number($('roomWidth').value);
  const l = Number($('roomLength').value);
  const h = Number($('roomHeight').value);
  if (![w, l, h].every(Number.isFinite) || w < 2 || w > 10 || l < 2 || l > 10 || h < 2 || h > 4) {
    status('Введите ширину и длину от 2 до 10 м, высоту от 2 до 4 м.');
    return;
  }
  room = { width: w, length: l, height: h };
  drawRoom();
  status('Размеры комнаты обновлены. Проверьте расположение модулей.');
}

function projectData() {
  return {
    version: 1,
    room,
    facadeColor,
    units: units.map(u => ({
      id: u.userData.unitId,
      type: u.userData.type,
      x: u.position.x,
      z: u.position.z,
      rotation: u.rotation.y,
      color: u.userData.saved.color || facadeColor
    }))
  };
}

function loadData(data) {
  if (!data || !data.room || !Array.isArray(data.units)) throw new Error('Неверный формат проекта');
  const r = data.room;
  if (![r.width, r.length, r.height].every(Number.isFinite) ||
      r.width < 2 || r.width > 10 || r.length < 2 || r.length > 10 || r.height < 2 || r.height > 4 ||
      data.units.length > 100) throw new Error('Некорректные параметры проекта');
  room = { width: r.width, length: r.length, height: r.height };
  $('roomWidth').value = room.width;
  $('roomLength').value = room.length;
  $('roomHeight').value = room.height;
  facadeColor = data.facadeColor || '#d8d0c1';
  document.querySelectorAll('.swatch').forEach(b => b.classList.toggle('active', b.dataset.color === facadeColor));
  clearGroup(unitGroup);
  units = [];
  selected = null;
  nextId = 1;
  drawRoom();
  for (const item of data.units) {
    if (!['base', 'drawer', 'tall', 'wall'].includes(item.type)) continue;
    const safe = {
      id: Number.isFinite(item.id) ? item.id : nextId,
      type: item.type,
      x: THREE.MathUtils.clamp(Number(item.x) || 0, -room.width / 2 + 0.35, room.width / 2 - 0.35),
      z: THREE.MathUtils.clamp(Number(item.z) || 0, -room.length / 2 + 0.3, room.length / 2 - 0.3),
      rotation: Number(item.rotation) || 0,
      color: /^#[0-9a-f]{6}$/i.test(item.color || '') ? item.color : facadeColor
    };
    nextId = Math.max(nextId, safe.id + 1);
    units.push(buildUnit(safe));
  }
  updateEstimate();
  status('Проект загружен.');
}

$('updateRoom').addEventListener('click', applyRoom);
document.querySelectorAll('[data-module]').forEach(b => b.addEventListener('click', () => addUnit(b.dataset.module)));

document.querySelectorAll('.swatch').forEach(b => b.addEventListener('click', () => {
  facadeColor = b.dataset.color;
  document.querySelectorAll('.swatch').forEach(s => s.classList.toggle('active', s === b));
  for (const unit of units) {
    unit.traverse(o => {
      if (o.isMesh && o.userData.part === 'facade') {
        o.material.color.set(facadeColor);
      }
    });
    unit.userData.saved.color = facadeColor;
  }
  status('Цвет фасадов изменён.');
}));

$('rotateModule').addEventListener('click', () => {
  if (!selected) return status('Сначала выберите модуль.');
  selected.rotation.y += Math.PI / 2;
  selected.userData.saved.rotation = selected.rotation.y;
});
$('deleteModule').addEventListener('click', () => {
  if (!selected) return status('Сначала выберите модуль.');
  unitGroup.remove(selected);
  units = units.filter(u => u !== selected);
  selected = null;
  selectUnit(null);
  updateEstimate();
  status('Модуль удалён.');
});

$('saveProject').addEventListener('click', () => {
  try {
    localStorage.setItem('forma-kitchen-project', JSON.stringify(projectData()));
    status('Проект сохранён в памяти этого браузера.');
  } catch (e) { status('Не удалось сохранить проект в браузере.'); }
});
$('loadProject').addEventListener('click', () => {
  try {
    const saved = localStorage.getItem('forma-kitchen-project');
    if (!saved) return status('Сохранённых проектов пока нет.');
    loadData(JSON.parse(saved));
  } catch (e) { status('Не удалось загрузить проект.'); }
});

$('exportProject').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(projectData(), null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'forma-kitchen-project.json'; a.click();
  URL.revokeObjectURL(url);
  status('Файл проекта подготовлен.');
});
$('importProject').addEventListener('click', () => $('importFile').click());
$('importFile').addEventListener('change', async e => {
  const file = e.target.files?.[0];
  if (!file) return;
  try { loadData(JSON.parse(await file.text())); }
  catch (err) { status('Не удалось импортировать файл: проверьте JSON.'); }
  e.target.value = '';
});
$('screenshot').addEventListener('click', () => {
  renderer.render(scene, camera);
  const a = document.createElement('a');
  a.download = 'forma-kitchen-3d.png';
  a.href = renderer.domElement.toDataURL('image/png');
  a.click();
});
$('resetCamera').addEventListener('click', () => {
  camera.position.set(6, 5.2, 7);
  orbit.target.set(0, room.height * 0.38, 0);
  orbit.update();
});

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const hitPoint = new THREE.Vector3();

function setPointer(event) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
}

renderer.domElement.addEventListener('pointerdown', e => {
  pointerDown = { x: e.clientX, y: e.clientY };
  moved = false;
  setPointer(e);
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects(unitGroup.children, true);
  const hit = hits.find(h => h.object.userData.unitId !== undefined);
  if (hit) {
    const id = hit.object.userData.unitId;
    const unit = units.find(u => u.userData.unitId === id);
    selectUnit(unit || null);
    dragging = true;
    orbit.enabled = false;
    raycaster.ray.intersectPlane(groundPlane, hitPoint);
    lastPointer = hitPoint.clone();
  } else {
    selectUnit(null);
  }
});
renderer.domElement.addEventListener('pointermove', e => {
  if (!dragging || !selected) return;
  if (pointerDown && Math.hypot(e.clientX - pointerDown.x, e.clientY - pointerDown.y) > 4) moved = true;
  setPointer(e);
  raycaster.setFromCamera(pointer, camera);
  if (!raycaster.ray.intersectPlane(groundPlane, hitPoint)) return;
  const dx = hitPoint.x - lastPointer.x;
  const dz = hitPoint.z - lastPointer.z;
  selected.position.x = THREE.MathUtils.clamp(selected.position.x + dx, -room.width / 2 + 0.35, room.width / 2 - 0.35);
  selected.position.z = THREE.MathUtils.clamp(selected.position.z + dz, -room.length / 2 + 0.3, room.length / 2 - 0.3);
  lastPointer.copy(hitPoint);
  selected.userData.saved.x = selected.position.x;
  selected.userData.saved.z = selected.position.z;
});
function endDrag() {
  if (dragging) {
    dragging = false;
    orbit.enabled = true;
    updateEstimate();
  }
}
renderer.domElement.addEventListener('pointerup', endDrag);
renderer.domElement.addEventListener('pointercancel', endDrag);
window.addEventListener('pointerup', endDrag);

function resize() {
  const w = Math.max(1, viewport.clientWidth);
  const h = Math.max(1, viewport.clientHeight);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
}
new ResizeObserver(resize).observe(viewport);
resize();
drawRoom();
addUnit('base');
addUnit('drawer');
addUnit('wall');
selectUnit(null);
updateEstimate();
$('year').textContent = new Date().getFullYear();

$('contactForm').addEventListener('submit', e => {
  e.preventDefault();
  $('formStatus').textContent = 'Это демонстрация: заявка не отправлена. Для реального приёма подключим сервис отправки формы.';
});

function animate() {
  requestAnimationFrame(animate);
  orbit.update();
  renderer.render(scene, camera);
}
animate();

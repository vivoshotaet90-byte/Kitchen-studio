import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/controls/OrbitControls.js';

const $ = id => document.getElementById(id);
const viewport = $('viewport');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#e8e9e3');

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
camera.position.set(6, 5.2, 7);

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
viewport.appendChild(renderer.domElement);

const orbit = new OrbitControls(camera, renderer.domElement);
orbit.enableDamping = true;
orbit.target.set(0, 1, 0);
orbit.maxPolarAngle = Math.PI * 0.49;
orbit.minDistance = 3;
orbit.maxDistance = 18;

scene.add(new THREE.HemisphereLight(0xffffff, 0x898b7e, 2));
const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(4, 8, 5);
sun.castShadow = true;
scene.add(sun);

const floorMat = new THREE.MeshStandardMaterial({ color: '#d9d9d0', roughness: 0.9 });
const wallMat = new THREE.MeshStandardMaterial({ color: '#f7f5ee', roughness: 0.95, side: THREE.DoubleSide });
const cabinetMat = new THREE.MeshStandardMaterial({ color: '#d8d0c1', roughness: 0.65 });
const topMat = new THREE.MeshStandardMaterial({ color: '#8b897f', roughness: 0.45 });
const detailMat = new THREE.MeshStandardMaterial({ color: '#77776d', metalness: 0.55, roughness: 0.35 });

let room = { width: 4, length: 4, height: 2.7 };
let units = [];
let selected = null;
let nextId = 1;
let facadeColor = '#d8d0c1';
let dragging = false;
let moved = false;
let lastPointer = null;
let pointerDown = null;

const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), floorMat);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.015;
floor.receiveShadow = true;
scene.add(floor);

const roomGroup = new THREE.Group();
scene.add(roomGroup);
const unitGroup = new THREE.Group();
scene.add(unitGroup);

function clearGroup(group) {
  while (group.children.length) {
    const child = group.children[0];
    group.remove(child);
    child.traverse?.(obj => {
      if (obj.geometry) obj.geometry.dispose();
    });
  }
}

function addBox(parent, size, position, material, name = '') {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.part = name;
  parent.add(mesh);
  return mesh;
}

function drawRoom() {
  clearGroup(roomGroup);
  const { width: w, length: l, height: h } = room;
  addBox(roomGroup, [w, 0.08, l], [0, 0, 0], floorMat, 'floor');

  // Back wall and two side walls
  addBox(roomGroup, [w, h, 0.08], [0, h / 2, -l / 2], wallMat, 'wall');
  addBox(roomGroup, [0.08, h, l], [-w / 2, h / 2, 0], wallMat, 'wall');
  addBox(roomGroup, [0.08, h, l], [w / 2, h / 2, 0], wallMat, 'wall');

  // Subtle floor grid
  const grid = new THREE.GridHelper(Math.max(w, l), Math.round(Math.max(w, l) * 2), 0xb7b8ad, 0xd0d1c8);
  grid.position.y = 0.045;
  roomGroup.add(grid);

  orbit.target.set(0, h * 0.38, 0);
  orbit.update();
}


function dimensions(type) {
  const defs = {
    base:   { w:.6, h:.86, d:.58, price:2900, name:'Нижний шкаф' },
    drawer: { w:.6, h:.86, d:.58, price:3600, name:'Шкаф с ящиками' },
    tall:   { w:.6, h:Math.min(2.2, room.height-.2), d:.58, price:4200, name:'Высокий шкаф' },
    wall:   { w:.6, h:.72, d:.35, price:2400, name:'Навесной шкаф' },
    fridge: { w:.72, h:1.85, d:.7, price:9500, name:'Холодильник' },
    sink:   { w:.6, h:.86, d:.58, price:1800, name:'Мойка' },
    faucet: { w:.16, h:.35, d:.16, price:650, name:'Кран' },
    stove:  { w:.6, h:.08, d:.52, price:2200, name:'Варочная панель' },
    oven:   { w:.6, h:.6, d:.55, price:3200, name:'Духовка' },
    window: { w:1.2, h:1.0, d:.09, price:0, name:'Окно' },
    door:   { w:.9, h:2.05, d:.1, price:0, name:'Дверь' },
    table:  { w:1.2, h:.76, d:.75, price:2500, name:'Обеденный стол' },
    chair:  { w:.42, h:.9, d:.42, price:700, name:'Стул' }
  };
  return defs[type] || defs.base;
}



function buildUnit(data) {
  const dim = dimensions(data.type);
  const group = new THREE.Group();
  group.userData.unitId = data.id;
  group.userData.type = data.type;

  const facade = new THREE.MeshStandardMaterial({
    color: data.color || facadeColor,
    roughness: .58
  });
  const dark = new THREE.MeshStandardMaterial({ color:'#454943', roughness:.45 });
  const metal = new THREE.MeshStandardMaterial({ color:'#aeb1aa', metalness:.7, roughness:.25 });
  const glass = new THREE.MeshStandardMaterial({
    color:'#a9d5e7', metalness:.15, roughness:.18,
    transparent:true, opacity:.72
  });
  const wood = new THREE.MeshStandardMaterial({ color:'#b29a7b', roughness:.7 });
  const black = new THREE.MeshStandardMaterial({ color:'#222522', roughness:.3 });

  const box = (size, pos, mat, part='') =>
    addBox(group, size, pos, mat, part);

  const cyl = (radius, height, pos, mat, sides=20) => {
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(radius, radius, height, sides), mat
    );
    mesh.position.set(...pos);
    mesh.castShadow = true;
    mesh.userData.part = '';
    mesh.userData.unitId = data.id;
    group.add(mesh);
    return mesh;
  };

  const t = data.type;
  const isWall = t === 'wall';
  let defaultY = dim.h/2 + .05;

  if (t === 'window') defaultY = Math.min(room.height*.62, room.height-.65);
  if (t === 'door') defaultY = dim.h/2 + .05;
  if (t === 'faucet') defaultY = .98;
  if (t === 'stove') defaultY = .95;
  if (t === 'oven') defaultY = .52;
  if (t === 'wall') defaultY = Math.min(room.height-dim.h/2-.2, 1.85);
  if (t === 'chair') defaultY = .45;

  if (['base','drawer','tall','wall'].includes(t)) {
    const bodyH = dim.h - .035;
    box([dim.w-.035, bodyH, dim.d-.025], [0,0,0], wood, 'body');
    box([dim.w-.07, dim.h-.08, .035], [0,0,dim.d/2+.02], facade, 'facade');

    if (t === 'drawer') {
      for (let i=0; i<3; i++) {
        const yy = -dim.h/2 + dim.h*(i+.5)/3;
        box([dim.w*.52,.025,.025], [0,yy,dim.d/2+.045], metal);
      }
    } else {
      box([.16,.025,.025], [0,0,dim.d/2+.045], metal);
    }
    if (!isWall) {
      box([dim.w+.025,.045,dim.d+.035], [0,dim.h/2+.025,0], topMat, 'countertop');
      box([dim.w-.07,.04,dim.d-.07], [0,-dim.h/2+.025,0], wood);
    }
  }

  if (t === 'fridge') {
    box([dim.w,dim.h,dim.d], [0,0,0], facade, 'facade');
    box([dim.w-.035,dim.h*.57,.025], [0,dim.h*.21,dim.d/2+.014], metal);
    box([dim.w-.035,.018,.025], [0,-dim.h*.08,dim.d/2+.016], dark);
    box([.025,dim.h*.35,.035], [dim.w*.32,dim.h*.23,dim.d/2+.025], metal);
    box([.025,dim.h*.28,.035], [dim.w*.32,-dim.h*.28,dim.d/2+.025], metal);
  }

  if (t === 'sink') {
    box([dim.w, .07, dim.d], [0,0,0], topMat);
    box([dim.w*.66,.035,dim.d*.56], [0,.045,0], dark);
    box([dim.w*.58,.025,dim.d*.48], [0,.065,0], metal);
    box([.035,.02,.035], [0,.085,0], dark);
  }

  if (t === 'faucet') {
    cyl(.035,.22,[0,-.08,0],metal);
    cyl(.025,.18,[0,.035,-.025],metal);
    cyl(.022,.15,[0,.105,.045],metal);
    cyl(.018,.07,[0,.17,.075],metal);
  }

  if (t === 'stove') {
    box([dim.w,.065,dim.d],[0,0,0],black,'facade');
    for (const x of [-.17,.17]) {
      for (const z of [-.13,.13]) {
        cyl(.085,.018,[x,.042,z],metal);
        cyl(.057,.02,[x,.054,z],black);
      }
    }
  }

  if (t === 'oven') {
    box([dim.w,dim.h,dim.d],[0,0,0],facade,'facade');
    box([dim.w*.76,dim.h*.53,.025],[0,-.04,dim.d/2+.018],black);
    box([dim.w*.65,.025,.025],[0,dim.h*.34,dim.d/2+.04],metal);
    for (let i=0;i<3;i++) cyl(.025,.025,[-.16+i*.16,dim.h*.39,dim.d/2+.04],metal);
  }

  if (t === 'window') {
    box([dim.w,dim.h,.06],[0,0,0],wood);
    box([dim.w-.12,dim.h-.12,.025],[0,0,.04],glass,'facade');
    box([.035,dim.h-.08,.025],[0,0,.06],wood);
    box([dim.w-.08,.035,.025],[0,0,.06],wood);
    box([.025,dim.h-.08,.025],[0,0,.075],metal);
  }

  if (t === 'door') {
    box([dim.w,dim.h,.07],[0,0,0],wood,'facade');
    box([dim.w*.65,dim.h*.65,.018],[0,.05,.045],facade);
    cyl(.025,.025,[dim.w*.32,-.05,.07],metal);
  }

  if (t === 'table') {
    box([dim.w,.07,dim.d],[0,dim.h/2,0],wood,'facade');
    for (const x of [-dim.w*.42,dim.w*.42]) {
      for (const z of [-dim.d*.36,dim.d*.36]) {
        box([.055,dim.h-.06,.055],[x,-.025,z],dark);
      }
    }
  }

  if (t === 'chair') {
    box([dim.w,.06,dim.d*.9],[0,0,0],wood,'facade');
    for (const x of [-dim.w*.38,dim.w*.38]) {
      for (const z of [-dim.d*.38,dim.d*.38]) {
        box([.035,.43,.035],[x,-.22,z],wood);
      }
    }
    box([dim.w,.43,.045],[0,.24,-dim.d*.4],wood);
    box([dim.w,.06,dim.d*.88],[0,.47,-dim.d*.4],facade);
  }

  let x = Number.isFinite(data.x) ? data.x : 0;
  let z = Number.isFinite(data.z) ? data.z : 0;

  group.position.set(x, defaultY, z);
  group.rotation.y = data.rotation || 0;
  group.userData.price = dim.price;
  group.userData.name = dim.name;
  group.userData.dim = dim;
  group.userData.saved = { ...data };
  group.traverse(obj => {
    if (obj.isMesh) obj.userData.unitId = data.id;
  });
  unitGroup.add(group);
  return group;
}



function addUnit(type) {
  const dim = dimensions(type);
  const id = nextId++;
  let x = 0;
  let z = 0;

  if (['base','drawer','wall','sink','stove','oven'].includes(type)) {
    x = THREE.MathUtils.clamp(
      -room.width/2 + .4 + units.length*.18,
      -room.width/2 + dim.w/2,
      room.width/2 - dim.w/2
    );
    z = -room.length/2 + dim.d/2 + .08;
  } else if (type === 'window' || type === 'door') {
    x = 0;
    z = -room.length/2 + .07;
  } else if (type === 'fridge') {
    x = room.width/2 - dim.w/2 - .1;
    z = -room.length/2 + dim.d/2 + .08;
  } else if (type === 'faucet') {
    x = 0;
    z = -room.length/2 + .4;
  } else {
    x = 0;
    z = .2;
  }

  x = THREE.MathUtils.clamp(x, -room.width/2 + dim.w/2, room.width/2 - dim.w/2);
  z = THREE.MathUtils.clamp(z, -room.length/2 + dim.d/2, room.length/2 - dim.d/2);

  const data = { id, type, x, z, rotation:0, color:facadeColor };
  const unit = buildUnit(data);
  units.push(unit);
  selectUnit(unit);
  updateEstimate();
  status('Добавлен предмет: ' + unit.userData.name + '. Его можно перетащить в 3D.');
}


function selectUnit(unit) {
  if (selected) selected.traverse(o => {
    if (o.isMesh && o.material?.emissive) o.material.emissive.set('#000000');
  });
  selected = unit;
  if (selected) {
    selected.traverse(o => {
      if (o.isMesh && o.material?.emissive) o.material.emissive.set('#222218');
    });
    $('selectionInfo').textContent = selected.userData.name + ' · ширина 60 см';
  } else {
    $('selectionInfo').textContent = 'Выберите модуль в 3D, чтобы изменить его.';
  }
}

function updateEstimate() {
  const price = units.reduce((sum, u) => sum + u.userData.price, 0);
  const length = units.filter(u => ['base','drawer','sink','stove','oven'].includes(u.userData.type)).reduce((sum, u) => sum + u.userData.dim.w, 0);
  $('totalPrice').textContent = price.toLocaleString('ru-RU') + ' MDL';
  $('moduleCount').textContent = units.length;
  $('runLength').textContent = length.toFixed(1) + ' м';
}

function status(message) {
  $('status').textContent = message;
}

function applyRoom() {
  const w = Number($('roomWidth').value);
  const l = Number($('roomLength').value);
  const h = Number($('roomHeight').value);
  if (![w, l, h].every(Number.isFinite) || w < 2 || w > 10 || l < 2 || l > 10 || h < 2 || h > 4) {
    status('Введите ширину и длину от 2 до 10 м, высоту от 2 до 4 м.');
    return;
  }
  room = { width: w, length: l, height: h };
  drawRoom();
  status('Размеры комнаты обновлены. Проверьте расположение модулей.');
}

function projectData() {
  return {
    version: 1,
    room,
    facadeColor,
    units: units.map(u => ({
      id: u.userData.unitId,
      type: u.userData.type,
      x: u.position.x,
      z: u.position.z,
      rotation: u.rotation.y,
      color: u.userData.saved.color || facadeColor
    }))
  };
}

function loadData(data) {
  if (!data || !data.room || !Array.isArray(data.units)) throw new Error('Неверный формат проекта');
  const r = data.room;
  if (![r.width, r.length, r.height].every(Number.isFinite) ||
      r.width < 2 || r.width > 10 || r.length < 2 || r.length > 10 || r.height < 2 || r.height > 4 ||
      data.units.length > 100) throw new Error('Некорректные параметры проекта');
  room = { width: r.width, length: r.length, height: r.height };
  $('roomWidth').value = room.width;
  $('roomLength').value = room.length;
  $('roomHeight').value = room.height;
  facadeColor = data.facadeColor || '#d8d0c1';
  document.querySelectorAll('.swatch').forEach(b => b.classList.toggle('active', b.dataset.color === facadeColor));
  clearGroup(unitGroup);
  units = [];
  selected = null;
  nextId = 1;
  drawRoom();
  for (const item of data.units) {
    if (!['base','drawer','tall','wall','fridge','sink','faucet','stove','oven','window','door','table','chair'].includes(item.type)) continue;
    const safe = {
      id: Number.isFinite(item.id) ? item.id : nextId,
      type: item.type,
      x: THREE.MathUtils.clamp(Number(item.x) || 0, -room.width / 2 + 0.35, room.width / 2 - 0.35),
      z: THREE.MathUtils.clamp(Number(item.z) || 0, -room.length / 2 + 0.3, room.length / 2 - 0.3),
      rotation: Number(item.rotation) || 0,
      color: /^#[0-9a-f]{6}$/i.test(item.color || '') ? item.color : facadeColor
    };
    nextId = Math.max(nextId, safe.id + 1);
    units.push(buildUnit(safe));
  }
  updateEstimate();
  status('Проект загружен.');
}

$('updateRoom').addEventListener('click', applyRoom);
document.querySelectorAll('[data-module]').forEach(b => b.addEventListener('click', () => addUnit(b.dataset.module)));

document.querySelectorAll('.swatch').forEach(b => b.addEventListener('click', () => {
  facadeColor = b.dataset.color;
  document.querySelectorAll('.swatch').forEach(s => s.classList.toggle('active', s === b));
  for (const unit of units) {
    unit.traverse(o => {
      if (o.isMesh && o.userData.part === 'facade') {
        o.material.color.set(facadeColor);
      }
    });
    unit.userData.saved.color = facadeColor;
  }
  status('Цвет фасадов изменён.');
}));

$('rotateModule').addEventListener('click', () => {
  if (!selected) return status('Сначала выберите модуль.');
  selected.rotation.y += Math.PI / 2;
  selected.userData.saved.rotation = selected.rotation.y;
});
$('deleteModule').addEventListener('click', () => {
  if (!selected) return status('Сначала выберите модуль.');
  unitGroup.remove(selected);
  units = units.filter(u => u !== selected);
  selected = null;
  selectUnit(null);
  updateEstimate();
  status('Модуль удалён.');
});

$('saveProject').addEventListener('click', () => {
  try {
    localStorage.setItem('forma-kitchen-project', JSON.stringify(projectData()));
    status('Проект сохранён в памяти этого браузера.');
  } catch (e) { status('Не удалось сохранить проект в браузере.'); }
});
$('loadProject').addEventListener('click', () => {
  try {
    const saved = localStorage.getItem('forma-kitchen-project');
    if (!saved) return status('Сохранённых проектов пока нет.');
    loadData(JSON.parse(saved));
  } catch (e) { status('Не удалось загрузить проект.'); }
});

$('exportProject').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(projectData(), null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'forma-kitchen-project.json'; a.click();
  URL.revokeObjectURL(url);
  status('Файл проекта подготовлен.');
});
$('importProject').addEventListener('click', () => $('importFile').click());
$('importFile').addEventListener('change', async e => {
  const file = e.target.files?.[0];
  if (!file) return;
  try { loadData(JSON.parse(await file.text())); }
  catch (err) { status('Не удалось импортировать файл: проверьте JSON.'); }
  e.target.value = '';
});
$('screenshot').addEventListener('click', () => {
  renderer.render(scene, camera);
  const a = document.createElement('a');
  a.download = 'forma-kitchen-3d.png';
  a.href = renderer.domElement.toDataURL('image/png');
  a.click();
});
$('resetCamera').addEventListener('click', () => {
  camera.position.set(6, 5.2, 7);
  orbit.target.set(0, room.height * 0.38, 0);
  orbit.update();
});

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const hitPoint = new THREE.Vector3();

function setPointer(event) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
}

renderer.domElement.addEventListener('pointerdown', e => {
  pointerDown = { x: e.clientX, y: e.clientY };
  moved = false;
  setPointer(e);
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects(unitGroup.children, true);
  const hit = hits.find(h => h.object.userData.unitId !== undefined);
  if (hit) {
    const id = hit.object.userData.unitId;
    const unit = units.find(u => u.userData.unitId === id);
    selectUnit(unit || null);
    dragging = true;
    orbit.enabled = false;
    raycaster.ray.intersectPlane(groundPlane, hitPoint);
    lastPointer = hitPoint.clone();
  } else {
    selectUnit(null);
  }
});
renderer.domElement.addEventListener('pointermove', e => {
  if (!dragging || !selected) return;
  if (pointerDown && Math.hypot(e.clientX - pointerDown.x, e.clientY - pointerDown.y) > 4) moved = true;
  setPointer(e);
  raycaster.setFromCamera(pointer, camera);
  if (!raycaster.ray.intersectPlane(groundPlane, hitPoint)) return;
  const dx = hitPoint.x - lastPointer.x;
  const dz = hitPoint.z - lastPointer.z;
  selected.position.x = THREE.MathUtils.clamp(selected.position.x + dx, -room.width / 2 + 0.35, room.width / 2 - 0.35);
  selected.position.z = THREE.MathUtils.clamp(selected.position.z + dz, -room.length / 2 + 0.3, room.length / 2 - 0.3);
  lastPointer.copy(hitPoint);
  selected.userData.saved.x = selected.position.x;
  selected.userData.saved.z = selected.position.z;
});
function endDrag() {
  if (dragging) {
    dragging = false;
    orbit.enabled = true;
    updateEstimate();
  }
}
renderer.domElement.addEventListener('pointerup', endDrag);
renderer.domElement.addEventListener('pointercancel', endDrag);
window.addEventListener('pointerup', endDrag);

function resize() {
  const w = Math.max(1, viewport.clientWidth);
  const h = Math.max(1, viewport.clientHeight);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
}
new ResizeObserver(resize).observe(viewport);
resize();
drawRoom();
addUnit('base');
addUnit('drawer');
addUnit('wall');
selectUnit(null);
updateEstimate();
$('year').textContent = new Date().getFullYear();

$('contactForm').addEventListener('submit', e => {
  e.preventDefault();
  $('formStatus').textContent = 'Это демонстрация: заявка не отправлена. Для реального приёма подключим сервис отправки формы.';
});

function animate() {
  requestAnimationFrame(animate);
  orbit.update();
  renderer.render(scene, camera);
}
animate();
